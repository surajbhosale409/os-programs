Hello sir,
         

1. compile using following command
   
==> nasm -f bin my_os.asm -o my_os.iso

2. make bootable pd

==> sudo dd if=my_os.iso of=/dev/???

3. Boot from PD


Thank you...
